import { Routes, Route } from "react-router-dom";
import { CssBaseline, ThemeProvider } from "@mui/material";
import { ColorModeContext, useMode } from "./theme";
import Topbar from "./scenes/global/Topbar";
import Sidebar from "./scenes/global/Sidebar";
import Dashboard from "./scenes/dashboard";
import Allusers from "./scenes/allusers";
import CFM from "./scenes/cfm";
import Chief from "./scenes/chief";
import Clerk from "./scenes/clerk";
import Form from "./scenes/form";
import Buildingplanevaluator from "./scenes/bpe";
import Encoder from "./scenes/encoder";

function App() {
  const [theme, colorMode] = useMode();

  return (
    <ColorModeContext.Provider value={colorMode}>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <div className="app">
          <Sidebar/>
          <main className="content">
            <Topbar/>
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/allusers" element={<Allusers />} />
              <Route path="/cfm" element={<CFM />} />
              <Route path="/chief" element={<Chief />} />
              <Route path="/clerk" element={<Clerk />} />
              <Route path="/bpe" element={<Buildingplanevaluator />} />
              <Route path="/encoder" element={<Encoder />} />
              <Route path="/form" element={<Form />} />
            </Routes>
          </main>
        </div>
      </ThemeProvider>
    </ColorModeContext.Provider>
  );
}

export default App;
import { Box, IconButton, Typography } from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import { tokens } from "../../theme";
import { UserInformationTeam } from "../../database/UserInformation";
import { useTheme } from "@mui/material";
import InputBase from "@mui/material/InputBase";
import SearchIcon from "@mui/icons-material/Search";
import Header from "../../components/Header";

const Allusers = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  const columns = [
    { field: "id", headerName: "ID", flex: 0.2},
    { field: "accountNum", headerName: "Account Number", flex: 1 },
    {
      field: "firstname",
      headerName: "Firstname",
      cellClassName: "name-column--cell",
    },
    {
      field: "lastname",
      headerName: "Lastname",
      cellClassName: "name-column--cell",
    },
    {
      field: "address",
      headerName: "Address",
      headerAlign: "left",
      align: "left",
    },
    {
      field: "designation",
      headerName: "Designation",
      flex: 1,
    },
    {
      field: "email",
      headerName: "Email Address",
      flex: 1,
    },
    {
      field: "group",
      headerName: "Group",
      flex: 1,
      renderCell: ({ row: { group } }) => {
        return (
          <Typography color={colors.white[100]} sx={{ ml: "5px" }}>
            {group}
          </Typography>  
        );
      },
    },
  ];

  return (
    <Box m="15px">
      <Header
        title="All Users"
      />
      <Box
        sx={{ width: '30%', mt:-2 }}
        backgroundColor={colors.black[400]}
        borderRadius="3px"
      >
        <InputBase sx={{ ml: 2, width: '80%' }} placeholder="Search" />
        <IconButton type="button" sx={{ p: 1 }}>
          <SearchIcon />
        </IconButton>
      </Box>
      <Box
        m="10px 0 0 0"
        height="75vh"
        sx={{
          "& .MuiDataGrid-root": {
            border: "none",
          },
          "& .MuiDataGrid-cell": {
            borderBottom: "none",
          },
          "& .name-column--cell": {
            color: colors.red[300],
          },
          "& .MuiDataGrid-columnHeaders": {
            backgroundColor: colors.blue[800],
            borderBottom: "none",
          },
          "& .MuiDataGrid-virtualScroller": {
            backgroundColor: colors.black[400],
          },
          "& .MuiDataGrid-footerContainer": {
            borderTop: "none",
            backgroundColor: colors.blue[800],
          },
        }}
      >
        <DataGrid
          rows={UserInformationTeam}
          columns={columns}
        />
      </Box>
    </Box>
  );
};

export default Allusers;

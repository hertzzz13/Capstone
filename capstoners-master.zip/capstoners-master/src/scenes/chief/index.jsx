import { Box, Typography, useTheme } from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import { tokens } from "../../theme";
import { UserInformationTeam } from "../../database/UserInformation";
import Header from "../../components/Header";

const Chief = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  const filteredData = UserInformationTeam.filter((user) => user.group === "Chief, FSES");

  const columns = [
    { field: "id", headerName: "ID", flex: 0.1 },
    { field: "accountNum", headerName: "Account Number", flex: 1 },
    {
      field: "firstname",
      headerName: "Firstname",
      cellClassName: "name-column--cell",
    },
    {
      field: "lastname",
      headerName: "Lastname",
      cellClassName: "name-column--cell",
    },
    {
      field: "address",
      headerName: "Address",
      headerAlign: "left",
      align: "left",
    },
    {
      field: "designation",
      headerName: "Designation",
      flex: 1,
    },
    {
      field: "email",
      headerName: "Email Address",
      flex: 1,
    },
    {
      field: "group",
      headerName: "Group",
      flex: 1,
      renderCell: ({ row: { group } }) => {
        return (
          <Typography color={colors.white[100]} sx={{ ml: "5px" }}>
            {group}
          </Typography>
        );
      },
    },
  ];

  return (
    <Box m="15px">
      <Header title="Chief, FSES" />
      <Box
        m="10px 0 0 0"
        height="75vh"
        sx={{
          "& .MuiDataGrid-root": {
            border: "none",
          },
          "& .MuiDataGrid-cell": {
            borderBottom: "none",
          },
          "& .name-column--cell": {
            color: colors.red[300],
          },
          "& .MuiDataGrid-columnHeaders": {
            backgroundColor: colors.blue[800],
            borderBottom: "none",
          },
          "& .MuiDataGrid-virtualScroller": {
            backgroundColor: colors.black[400],
          },
          "& .MuiDataGrid-footerContainer": {
            borderTop: "none",
            backgroundColor: colors.blue[800],
          },
          "& .MuiCheckbox-root": {
            color: `${colors.red[200]} !important`,
          },
        }}
      >
        <DataGrid checkboxSelection rows={filteredData} columns={columns} />
      </Box>
    </Box>
  );
};

export default Chief;